#include "de.h"
#include "time.h"
#include <fstream>
#include <sstream>
#include<algorithm>
#include <vector>
#include <numeric>
#include <iomanip>
#include <cstdlib>


int g_function_number;
int g_problem_size;
unsigned int g_max_num_evaluations;
void (*gl_func)(double*, double*, int, int, int);
Fitness g_optimize_fitness;
double Fx[12] = {300, 400,600,800,900,1800,2000,2200,2300,2400,2600,2700};
//number of runs
int num_runs = 30;

//
int g_pop_size;
double g_arc_rate;
int g_memory_size;
double g_p_best_rate;

//for output file
void print_results(string file_name);
double records[30][16];
string code;
int run_id;

int main(int argc, char** argv) {
	// rand_seed
	cout << scientific << setprecision(8);
	string code2;
	double seed[1000];
	fstream seed_file;
	seed_file.open("input_data/Rand_Seeds.txt", ios::in);
	for (int i = 0; i < 1000; i++) {
		seed_file >> seed[i];
	}

	//dimension size. please select from 10, 20
	g_problem_size = 10;
	//available number of fitness evaluations
	//g_max_num_evaluations
	if (g_problem_size == 10) g_max_num_evaluations = 1000000;
	if (g_problem_size == 20)  g_max_num_evaluations = 10000000;
	//MLS-LSHADE parameters
	g_pop_size = (int)round(g_problem_size * 18);
	g_memory_size = round(0.06 * g_problem_size * g_problem_size);
	g_arc_rate = 2.6;
	g_p_best_rate = 0.11;


	gl_func = &cec22_test_func;
	stringstream file_name2;
	file_name2 << "tables/MLS-LSHADE_(Results_for_" << g_problem_size << "D_" << code2 << ")" << "_fin.txt";
	ofstream fout2;
	fout2.open((file_name2.str()).c_str(), ios::out);
	for (int i = 0; i < 1; i++) {
		g_function_number = i + 1;
		g_optimize_fitness = Fx[g_function_number-1];
		cout << "Problem code = " << code << endl;
		cout << "\n-------------------------------------------------------" << endl;
		cout << "Function = " << g_function_number << ", Dimension size = " << g_problem_size << "\n" << endl;
		vector<Fitness> bsf_fitness_array(num_runs);
		Fitness mean_bsf_fitness = 0;
		Fitness std_bsf_fitness = 0;
		Fitness best_bsf_fitness = 0;
		Fitness worst_bsf_fitness = 0;
		Fitness median_bsf_fitness = 0;
		for (int j = 0; j < num_runs; j++) {
			//init seed 
			run_id = j;
			int seed_ind = (g_problem_size / 10 * g_function_number * num_runs + j) - num_runs;
			seed_ind %= 1000;
			srand(seed[seed_ind]);

			searchAlgorithm* alg = new MLS_LSHADE();
			bsf_fitness_array[j] = alg->run();
			cout << j + 1 << "th run, " << "error value = " << bsf_fitness_array[j] << endl;
			delete alg;
			alg = NULL;
		}
		//д��result_


		string result_file= "results_/results_MLS_LSHADE_" + to_string(g_problem_size) + "_2022_fin.txt";
		ofstream fout_re;
		fout_re.open(result_file, ios::app);
		double mean_re=0;
		for (int j = 0; j < num_runs; j++)
		{
			mean_re += bsf_fitness_array[j];
		}
		mean_re = mean_re / 30;
		double var_re = 0;
		for (int j = 0; j < num_runs; j++)
		{
			var_re += (bsf_fitness_array[j] - mean_re) * (bsf_fitness_array[j] - mean_re);
		}
		var_re = sqrt(var_re / 30);
		fout_re << "F" << to_string(g_function_number) << " " << scientific<<mean_re << " " << "(" << var_re << ")" << " ";
		for (int j = 0; j < num_runs; j++)
		{
			fout_re << scientific << bsf_fitness_array[j] << " ";
		}
		fout_re << endl;
		fout_re.close();


		// print results to file
		stringstream file_name;
		file_name << "MLS-LSHADE_(" << code << ")_" << g_function_number << "_" << g_problem_size << ".txt";
		print_results(file_name.str());
		sort(bsf_fitness_array.begin(), bsf_fitness_array.end());
		best_bsf_fitness = bsf_fitness_array[0];
		worst_bsf_fitness = bsf_fitness_array[num_runs - 1];
		median_bsf_fitness = (bsf_fitness_array[14] + bsf_fitness_array[15]) / 2.0;

		for (int j = 0; j < num_runs; j++) mean_bsf_fitness += bsf_fitness_array[j];
		mean_bsf_fitness /= num_runs;

		for (int j = 0; j < num_runs; j++) std_bsf_fitness += pow((mean_bsf_fitness - bsf_fitness_array[j]), 2.0);
		std_bsf_fitness /= num_runs;
		std_bsf_fitness = sqrt(std_bsf_fitness);

		cout << "\nmean = " << mean_bsf_fitness << ", std = " << std_bsf_fitness << endl;
		fout2 << best_bsf_fitness << '\t' << worst_bsf_fitness << '\t' << median_bsf_fitness << '\t' << mean_bsf_fitness << '\t' << std_bsf_fitness << endl;
		bsf_fitness_array.clear();
	}
	fout2.close();
	return 0;
}
void print_results(string file_name) {
	ofstream fout;
	fout.open(file_name.c_str(), ios::out);
	if (fout.is_open()) {
		fout << scientific << setprecision(8);
		for (int i = 0; i < 16; i++) {
			for (int j = 0; j < num_runs; j++) {
				fout << records[j][i] << " ";
			}
			fout << endl;
		}
	}
	else {
		cout << "Error! cannot onpen output file " << file_name << "." << endl;
	}

	fout.close();
}
